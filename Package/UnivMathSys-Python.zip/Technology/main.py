# MainRun File of Universal Mathematics System

    # Copyright (C) 2016 Zhang Chang-kai #
    # Contact via: phy.zhangck@gmail.com #
    # General Public License version 3.0 #

'''Main Operating File of UnivMathSys'''

def Success():

    print("Package Operating Normally")

if __name__ == "__main__":

    Success()

# End of Main Operating File of UnivMathSys
