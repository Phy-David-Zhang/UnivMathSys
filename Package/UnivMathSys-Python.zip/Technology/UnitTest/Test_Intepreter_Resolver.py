
import logging

Logger = logging.getLogger('Main')
Logger.setLevel('DEBUG')

StrHndlr = logging.StreamHandler()
StrHndlr.setFormatter(logging.Formatter\
    ('%(levelname)s: %(message)s'))
Logger.addHandler(StrHndlr)

import unittest
from Interpreter.resolver import FormulaAST

Engine = FormulaAST()

class Test_FormulaAST(unittest.TestCase):
    pass
