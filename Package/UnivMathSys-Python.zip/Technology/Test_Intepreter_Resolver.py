#! /usr/bin/env python3

import logging

# handler setup
StrHndlr = logging.StreamHandler()
StrHndlr.setFormatter(logging.Formatter\
    ('%(levelname)s: %(message)s'))

# logger setup
MainLogger = logging.getLogger('Main')
ResolverLogger = logging.getLogger('Resolver')
CompilerLogger = logging.getLogger('Compiler')

MainLogger.setLevel('WARNING')
ResolverLogger.setLevel('DEBUG')
CompilerLogger.setLevel('WARNING')

MainLogger.addHandler(StrHndlr)
ResolverLogger.addHandler(StrHndlr)
CompilerLogger.addHandler(StrHndlr)

import unittest
from Interpreter.resolver import FormulaAST

Engine = FormulaAST()

class Test_FormulaAST(unittest.TestCase):

    def setUp(self):
        Stat1 = "(_\\in A\\wedge _\\in B)\\vee _\\in C"
        Prop1 = "(_\\in A\\vee _\\in C)\\wedge(_\\in B\\vee _\\in C)"
        Stat2 = "_\\in A\\vee _\\in B"
        Prop2 = "_\\in A"
        Stat3 = "(_\\in A\\vee _\\in B)\\wedge _\\in C"
        Prop3 = "(_\\in A\\wedge _\\in C)\\vee(_\\in B\\wedge _\\in C)"
        Stat4 = ["_\\in C", Stat2]
        self.Status = Stat4
        self.Property = Prop2

    def xtest_Generator(self):
        try:
            Syntax, BsList = \
                Engine.Generate(self.Status)
            for f in BsList:
                f.Truth = True
            print(Syntax(), BsList)
        except Exception:
            MainLogger.exception("")

    def xtest_Enum(self):
        print(Engine.EnumTruth(4))

    def test_Resolver(self):
        try:
            print(Engine.Resolve(self.Status,
                self.Property))
        except Exception:
            MainLogger.exception("")

if __name__ == "__main__":
    unittest.main()
