# Initialization of Interpreter for UnivMathSys

    # Copyright (C) 2016 Zhang Chang-kai #
    # Contact via: phy.zhangck@gmail.com #
    # General Public License version 3.0 #

'''Initialization of Module Interpreter'''

# End of Initialization of Module Interpreter
