# Entrance of Symbolic Calculation of UnivMathSys

    # Copyright (C) 2016 Zhang Chang-kai #
    # Contact via: phy.zhangck@gmail.com #
    # General Public License version 3.0 #

'''Module Interpreter.enter of UnivMathSys'''


from Elementary.error import IntpnError, ProofNeeded


def Verify(Left, Rght):
    raise ProofNeeded

# End of Module Interpreter.enter of UnivMathSys
