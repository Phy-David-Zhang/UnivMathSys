# Abstract Syntax Tree Template For UnivMathSys

    # Copyright (C) 2016 Zhang Chang-kai #
    # Contact via: phy.zhangck@gmail.com #
    # General Public License version 3.0 #

'''Syntax Tree Template of UnivMathSys'''


import re


class BaseAST(object):

    def __init__(self, *args, **kwargs):
        self.Initio(self, *args, **kwargs)

    def Initio(self, Pattern):
        self._Pattern = re.compile(Pattern)

    def Analyse(self, Input):
        self.TokenList = GenTokens(Input)
        self.CurrToken = None
        self.NextToken = None
        self._Advance()
        return self._Final()

    def _Advance(self):
        self.CurrToken, self.NextToken = \
            self.NextToken, next(self.TokenList, None)

    def _Accept(self, Type):
        if self.NextToken:
            pass
