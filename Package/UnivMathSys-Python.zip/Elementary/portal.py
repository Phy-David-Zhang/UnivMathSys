#! /usr/bin/env python3
# -*- uft-8 -*-

class MathBasic(object):

    Definition = None
    Denotation = None
    Formulation = None

    @property
    def Define(self):
        return self.Definition

    @property
    def Symbol(self):
        return self.Denotation

    @property
    def MathForm(self):
        return self.Formulation

    @Symbol.setter
    def Symbol(self, NewSym):
        self.Denotation = NewSym

    @MathForm.setter
    def MathForm(self, NewForm):
        self.Formulation = NewForm
