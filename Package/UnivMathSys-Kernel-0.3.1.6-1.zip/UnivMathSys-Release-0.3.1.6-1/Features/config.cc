/* config file of smart UMS */

	/* Copyright (C) 2016 Zhang Chang-kai */
	/* Contact via: phy.zhangck@gmail.com */
	/* General Public License version 3.0 */

#include "Features/smartset.hh"
#include "Features/dynamic.hh"