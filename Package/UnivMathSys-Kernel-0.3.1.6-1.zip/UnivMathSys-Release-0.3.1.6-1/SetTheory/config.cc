/* config file of Set Theory */

	/* Copyright (C) 2016 Zhang Chang-kai */
	/* Contact via: phy.zhangck@gmail.com */
	/* General Public License version 3.0 */

#include "SetTheory/support.hh"
#include "SetTheory/basic.hh"
#include "SetTheory/Russell.hh"